<?php
/**
 * Plugin Name: ZarinPal Payment for EDD
 * Version: 2.2.0
 * Description: افزونه درگاه پرداخت <a href="https://zarinpal.com">زرین‌پال</a> برای افزونه‌ی EDD (هماهنگ با وب‌سرویس جدید V4).
 * Plugin URI: https://digifilestore.ir
 * Author: Mohammad AliPour
 * Email: worldmohammad@gmail.com
 */

// جلوگیری از دسترسی مستقیم
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// اضافه کردن واحد پولی ریال (در صورت نیاز)
if ( ! function_exists( 'edd_rial' ) ) {
	function edd_rial( $formatted, $currency, $price ) {
		return $price . ' ریال';
	}
}
add_filter( 'edd_rial_currency_filter_after', 'edd_rial', 10, 3 );

// ثبت درگاه در EDD
function add_zarinpal_gateway( $gateways ) {
	global $edd_options;
	$checkout_label = isset( $edd_options['zp_checkout_text'] ) ? $edd_options['zp_checkout_text'] : 'درگاه پرداخت زرین‌پال';

	$gateways['zarinpal'] = array(
		'admin_label'    => 'زرین‌پال',
		'checkout_label' => $checkout_label
	);
	return $gateways;
}
add_filter( 'edd_payment_gateways', 'add_zarinpal_gateway' );

// فرم پرداخت (خالی، چون نیازی به فرم در صفحه چک‌اوت نیست)
function zp_cc_form() {
	return;
}
add_action( 'edd_zarinpal_cc_form', 'zp_cc_form' );

// پردازش پرداخت و انتقال به زرین‌پال
function zp_process( $purchase_data ) {
	global $edd_options;

	$payment_data = array(
		'price'        => $purchase_data['price'],
		'date'         => $purchase_data['date'],
		'user_email'   => $purchase_data['post_data']['edd_email'],
		'purchase_key' => $purchase_data['purchase_key'],
		'currency'     => edd_get_currency(),
		'downloads'    => $purchase_data['downloads'],
		'cart_details' => $purchase_data['cart_details'],
		'user_info'    => $purchase_data['user_info'],
		'status'       => 'pending'
	);

	// ثبت پرداخت در دیتابیس EDD
	$payment_id = edd_insert_payment( $payment_data );

	if ( $payment_id ) {
		
		// ساخت آدرس بازگشت (شناسه پرداخت را در آدرس قرار می‌دهیم تا مشکل Session پیش نیاید)
		$callback_url = add_query_arg( 
			array(
				'verify'     => 'zarinpal',
				'payment_id' => $payment_id
			), 
			get_permalink( $edd_options['success_page'] ) 
		);

		$merchant_id = trim( $edd_options['zp_merchant'] );
		
		// بررسی واحد پولی تنظیم شده در EDD
		$currency = edd_get_currency();
		$zp_currency = ( $currency == 'IRT' || $currency == 'TOMAN' ) ? 'IRT' : 'IRR';
		$amount = round( $payment_data['price'] );

		// دریافت شماره موبایل (اگر در فیلدهای شخصی‌سازی شده EDD موجود باشد)
		$mobile = '';
		if ( ! empty( $_POST['edd_phone'] ) ) {
			$mobile = sanitize_text_field( $_POST['edd_phone'] );
		} elseif ( ! empty( $_POST['edd_mobile'] ) ) {
			$mobile = sanitize_text_field( $_POST['edd_mobile'] );
		} elseif ( ! empty( $purchase_data['user_info']['phone'] ) ) {
			$mobile = sanitize_text_field( $purchase_data['user_info']['phone'] );
		}

		$site_name = get_bloginfo( 'name' );
		$description = 'سفارش ' . $payment_id . ' در ' . $site_name;

		// اطلاعات برای ارسال به زرین‌پال
		$data = array(
			'merchant_id'  => $merchant_id,
			'amount'       => $amount,
			'currency'     => $zp_currency,
			'description'  => mb_substr( $description, 0, 250 ),
			'callback_url' => $callback_url,
			'metadata'     => array(
				'email'    => $payment_data['user_email'],
				'order_id' => (string) $payment_id
			)
		);

		// اضافه کردن موبایل به متادیتا در صورت وجود
		if ( ! empty( $mobile ) ) {
			$data['metadata']['mobile'] = $mobile;
		}

		// ارسال درخواست به زرین‌پال (V4)
		$response = wp_remote_post( 'https://payment.zarinpal.com/pg/v4/payment/request.json', array(
			'body'    => wp_json_encode( $data ),
			'headers' => array(
				'Content-Type' => 'application/json',
				'Accept'       => 'application/json'
			),
			'timeout' => 15,
		) );

		if ( is_wp_error( $response ) ) {
			wp_die( 'خطا در ارتباط با زرین‌پال: ' . $response->get_error_message() );
		}

		$body = wp_remote_retrieve_body( $response );
		$result = json_decode( $body, true );

		if ( isset( $result['data']['code'] ) && $result['data']['code'] == 100 ) {
			// ذخیره Authority در سفارش
			update_post_meta( $payment_id, '_zarinpal_authority', $result['data']['authority'] );
			
			// هدایت به درگاه
			$start_pay_url = 'https://payment.zarinpal.com/pg/StartPay/' . $result['data']['authority'];
			wp_redirect( $start_pay_url );
			exit;
		} else {
			$error_message = isset( $result['errors']['message'] ) ? $result['errors']['message'] : 'خطای ناشناخته';
			$error_code = isset( $result['errors']['code'] ) ? $result['errors']['code'] : '';
			wp_die( 'خطا در ساخت تراکنش زرین‌پال. کد خطا: ' . $error_code . ' - ' . $error_message );
		}

	} else {
		edd_send_back_to_checkout( '?payment-mode=' . $purchase_data['post_data']['edd-gateway'] );
	}
}
add_action( 'edd_gateway_zarinpal', 'zp_process' );

// تایید تراکنش در زمان بازگشت به سایت
function zp_verify() {
	global $edd_options;

	if ( isset( $_GET['verify'] ) && $_GET['verify'] == 'zarinpal' && isset( $_GET['Authority'] ) ) {

		// دریافت شناسه پرداخت از آدرس (بدون استفاده از Session)
		$payment_id = isset( $_GET['payment_id'] ) ? absint( $_GET['payment_id'] ) : 0;
		$authority  = sanitize_text_field( $_GET['Authority'] );
		$status     = isset( $_GET['Status'] ) ? sanitize_text_field( $_GET['Status'] ) : '';

		if ( ! $payment_id ) {
			wp_die( 'سفارش مورد نظر یافت نشد.' );
		}

		if ( $status == 'OK' ) {

			$merchant_id = trim( $edd_options['zp_merchant'] );
			$amount      = round( edd_get_payment_amount( $payment_id ) );

			// اطلاعات برای تایید تراکنش
			$data = array(
				'merchant_id' => $merchant_id,
				'amount'      => $amount,
				'authority'   => $authority
			);

			// ارسال درخواست تایید به زرین‌پال (V4)
			$response = wp_remote_post( 'https://payment.zarinpal.com/pg/v4/payment/verify.json', array(
				'body'    => wp_json_encode( $data ),
				'headers' => array(
					'Content-Type' => 'application/json',
					'Accept'       => 'application/json'
				),
				'timeout' => 15,
			) );

			if ( is_wp_error( $response ) ) {
				edd_update_payment_status( $payment_id, 'failed' );
				edd_insert_payment_note( $payment_id, 'خطا در ارتباط با سرور زرین‌پال هنگام تایید تراکنش.' );
				wp_redirect( get_permalink( $edd_options['failure_page'] ) );
				exit;
			}

			$body = wp_remote_retrieve_body( $response );
			$result = json_decode( $body, true );

			// کد 100 یعنی پرداخت موفق و 101 یعنی پرداخت قبلا تایید شده
			if ( isset( $result['data']['code'] ) && ( $result['data']['code'] == 100 || $result['data']['code'] == 101 ) ) {
				
				$ref_id = $result['data']['ref_id'];
				
				// تکمیل سفارش در EDD
				edd_insert_payment_note( $payment_id, 'پرداخت موفق. شماره پیگیری زرین‌پال: ' . $ref_id );
				edd_set_payment_transaction_id( $payment_id, $ref_id );
				edd_update_payment_status( $payment_id, 'publish' );
				edd_empty_cart();
				
				// انتقال به صفحه موفقیت
				edd_send_to_success_page();
				exit;
				
			} else {
				// پرداخت ناموفق بود
				$error_code = isset( $result['errors']['code'] ) ? $result['errors']['code'] : 'نامشخص';
				edd_insert_payment_note( $payment_id, 'تایید پرداخت شکست خورد. کد خطا: ' . $error_code );
				edd_update_payment_status( $payment_id, 'failed' );
				wp_redirect( get_permalink( $edd_options['failure_page'] ) );
				exit;
			}

		} else {
			// کاربر از درگاه انصراف داده است
			edd_insert_payment_note( $payment_id, 'کاربر از پرداخت انصراف داد یا تراکنش ناموفق بود.' );
			edd_update_payment_status( $payment_id, 'failed' ); // revoked/failed
			wp_redirect( get_permalink( $edd_options['failure_page'] ) );
			exit;
		}
	}
}
add_action( 'init', 'zp_verify' );

// تنظیمات افزونه در پیشخوان وردپرس
function zp_settings( $settings ) {
	$zarinpal_options = array(
		array(
			'id'   => 'zarinpal_settings',
			'type' => 'header',
			'name' => '<div style="color: #0071CE; font-size: 16px; font-weight: bold; border-bottom: 2px solid #0071CE; padding-bottom: 5px; margin-bottom: 10px;">💳 تنظیمات درگاه زرین‌پال</div>'
		),
		array(
			'id'   => 'zp_merchant',
			'type' => 'text',
			'name' => 'مرچنت‌کد (Merchant ID)',
			'desc' => '<br><small style="color: #666;">کد ۳۶ کاراکتری درگاه خود را که از پنل زرین‌پال دریافت کرده‌اید، اینجا وارد کنید.</small>',
			'size' => 'regular'
		),
		array(
			'id'   => 'zp_checkout_text',
			'type' => 'text',
			'name' => 'نام نمایشی در تسویه‌حساب',
			'desc' => '<br><small style="color: #666;">عنوانی که مشتری هنگام انتخاب روش پرداخت مشاهده می‌کند (مثال: پرداخت امن زرین‌پال).</small>',
			'default'=> 'درگاه پرداخت زرین‌پال'
		),
		array(
			'id'   => 'zp_guide_text',
			'type' => 'descriptive_text',
			'name' => 'ارسال شماره موبایل',
			'desc' => '<div style="background-color: #f0f8ff; border-right: 4px solid #0071CE; padding: 12px; border-radius: 4px; margin-top: 10px;"><p style="margin: 0; font-size: 13px; line-height:24px;"><b>نکته:</b> افزونه EDD به طور پیش‌فرض موبایل کاربر را دریافت نمی‌کند. اگر روی فرم خرید خود فیلد موبایل (با شناسه <code>edd_phone</code> یا <code>edd_mobile</code>) قرار دهید، این افزونه به صورت خودکار آن را شناسایی کرده و در جزئیات تراکنش در زرین‌پال، نمایش داده می شود.</p></div>'
		)
	);

	return array_merge( $settings, $zarinpal_options );
}
add_filter( 'edd_settings_gateways', 'zp_settings' );